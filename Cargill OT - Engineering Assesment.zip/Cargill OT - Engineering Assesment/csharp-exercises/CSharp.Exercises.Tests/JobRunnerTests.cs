﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;

namespace CSharp.Exercises.Tests;

[TestFixture]
public class JobRunnerTests
{
    [TestCase(1)]
    [TestCase(2)]
    [TestCase(3)]
    [TestCase(4)]
    [TestCase(5)]
    [TestCase(6)]
    [Repeat(10)]
    public async Task ShouldReturnWhenAllJobsAreComplete(int numberOfJobs)
    {
        var jobs = Enumerable
            .Range(0, numberOfJobs)
            .Select(_ => new Action(() => Thread.Sleep(10)));

        var jobRunner = new JobRunner(jobs);

        var jobRunnerTask = Task.Run(() => jobRunner.Run());
        var timeoutTask = Task.Delay(TimeSpan.FromSeconds(1)).ContinueWith(_ => Assert.Fail("Test timed out"));

        await Task.WhenAny(jobRunnerTask, timeoutTask);

        Assert.That(jobRunner.JobsCompleted, Is.EqualTo(numberOfJobs));
    }
}