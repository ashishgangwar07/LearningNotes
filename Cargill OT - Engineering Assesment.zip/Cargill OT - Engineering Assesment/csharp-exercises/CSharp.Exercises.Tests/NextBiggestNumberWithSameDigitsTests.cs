﻿using NUnit.Framework;

namespace CSharp.Exercises.Tests;

[TestFixture]
public class NextBiggestNumberWithSameDigitsTests
{
    [Test]
    public void ShouldReturnNextBiggestNumber()
    {
        Assert.That(NextBiggestNumberWithSameDigits.NextBiggestNumber(12), Is.EqualTo(21));
        Assert.That(NextBiggestNumberWithSameDigits.NextBiggestNumber(513), Is.EqualTo(531));
        Assert.That(NextBiggestNumberWithSameDigits.NextBiggestNumber(2017), Is.EqualTo(2071));
        Assert.That(NextBiggestNumberWithSameDigits.NextBiggestNumber(414), Is.EqualTo(441));
        Assert.That(NextBiggestNumberWithSameDigits.NextBiggestNumber(144), Is.EqualTo(414));
        Assert.That(NextBiggestNumberWithSameDigits.NextBiggestNumber(441), Is.EqualTo(-1));
        Assert.That(NextBiggestNumberWithSameDigits.NextBiggestNumber(0), Is.EqualTo(-1));
    }
}