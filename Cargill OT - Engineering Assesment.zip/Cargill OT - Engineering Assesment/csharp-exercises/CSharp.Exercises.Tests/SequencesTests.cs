﻿using NUnit.Framework;

namespace CSharp.Exercises.Tests;

[TestFixture]
public class SequencesTests
{
    [Test]
    public void GetNumberSequenceShouldReturnZeroToNine()
    {
        var expected = new[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
        CollectionAssert.AreEqual(expected, Sequences.GetNumberSequence());
    }

    [Test]
    public void GetCharSequenceShouldReturnAtoF()
    {
        var expected = new[] { 'A', 'B', 'C', 'D', 'E', 'F' };
        CollectionAssert.AreEqual(expected, Sequences.GetCharSequence());
    }

    [Test]
    public void GetCombinedSequence1ShouldReturnExpectedResult()
    {
        var expected = new[]
        {
            "A0", "A1", "A2", "A3", "A4", "A5", "A6", "A7", "A8", "A9",
            "B0", "B1", "B2", "B3", "B4", "B5", "B6", "B7", "B8", "B9",
            "C0", "C1", "C2", "C3", "C4", "C5", "C6", "C7", "C8", "C9",
            "D0", "D1", "D2", "D3", "D4", "D5", "D6", "D7", "D8", "D9",
            "E0", "E1", "E2", "E3", "E4", "E5", "E6", "E7", "E8", "E9",
            "F0", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9"
        };

        CollectionAssert.AreEqual(expected, Sequences.GetCombinedSequence1());
    }

    [Test]
    public void GetCombinedSequence2ShouldReturnExpectedResult()
    {
        var expected = new[] { "A0", "B1", "C2", "D3", "E4", "F5" };
        CollectionAssert.AreEqual(expected, Sequences.GetCombinedSequence2());
    }
}