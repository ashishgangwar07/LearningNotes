﻿using System;

namespace CSharp.Exercises;

public static class Palindromes
{
    /**
     * Should return true if a given string is a palindrome, and false otherwise. A string is a palindrome if it reads
     * the same forwards as it does backwards.
     *
     * For example:
     *   "a" should return true
     *   "abba" should return true
     *   "ab" should return false
     */
    public static bool IsPalindromic(string word)
    {
        try
        {
            // If the input is null, return false
            if (word == null)
                return false;

            // Start comparing from the beginning and end
            int left = 0;
            int right = word.Length - 1;

            // Keep comparing while left index is less than right index
            while (left < right)
            {
                // If characters don't match, it's not a palindrome
                if (word[left] != word[right])
                    return false;

                // Move the left index forward
                left++;

                // Move the right index backward
                right--;
            }

            // If loop completes, it means all characters matched — it's a palindrome
            return true;
        }
        catch (Exception ex)
        {
            // Catch any unexpected errors (just for safety) and return false
            Console.WriteLine($"Error in IsPalindromic: {ex.Message}");
            return false;
        }
    }
}
