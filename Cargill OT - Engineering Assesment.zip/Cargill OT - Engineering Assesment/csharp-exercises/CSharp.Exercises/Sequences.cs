﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CSharp.Exercises;

public static class Sequences
{
    /**
     * Generate the sequence 0 to 9.
     */
    public static IEnumerable<int> GetNumberSequence()
    {
        // This generates the numbers 0 to 9 using LINQ
        return Enumerable.Range(0, 10); // [0, 1, 2, ..., 9]
    }

    /**
     * Generate the sequence A to F.
     */
    public static IEnumerable<char> GetCharSequence()
    {
        // 'A' is character code 65
        // This generates characters from 'A' to 'F' using their ASCII codes
        return Enumerable.Range('A', 6).Select(c => (char)c); // ['A', 'B', 'C', 'D', 'E', 'F']
    }

    /**
     * Create a sequence of all combinations of the above two sequences,
     * i.e. A0, A1, A2, ..., A9, B0, B1, ..., F8, F9.
     */
    public static IEnumerable<string> GetCombinedSequence1()
    {
        // Get number sequence [0-9]
        var numberSequence = GetNumberSequence();

        // Get char sequence [A-F]
        var charSequence = GetCharSequence();

        // For each character A-F, combine it with each number 0-9
        // Example: For A -> A0, A1, ..., A9; For B -> B0, B1, ..., B9 ...
        return charSequence.SelectMany(c =>
            numberSequence.Select(n => $"{c}{n}")); // ["A0", "A1", ..., "F9"]
    }

    /**
     * Combine the first two sequences to produce the new sequence A0, B1, C2, D3, E4, F5
     */
    public static IEnumerable<string> GetCombinedSequence2()
    {
        var numberSequence = GetNumberSequence();   // [0, 1, 2, ..., 9]
        var charSequence = GetCharSequence();       // ['A', 'B', ..., 'F']

        // Zip combines both sequences one by one:
        // (A,0) → A0, (B,1) → B1, ..., (F,5) → F5
        return charSequence.Zip(numberSequence, (c, n) => $"{c}{n}"); // ["A0", "B1", ..., "F5"]
    }
}
