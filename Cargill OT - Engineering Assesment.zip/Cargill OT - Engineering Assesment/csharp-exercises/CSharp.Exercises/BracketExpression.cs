﻿using System;
using System.Collections.Generic;

namespace CSharp.Exercises;

public static class BracketExpression
{
    /**
     * This method checks if the input string has balanced brackets.
     * A string is balanced if every opening bracket has a correct closing bracket in the correct order.
     * Valid bracket types: (), {}, []
     */
    public static bool IsBalanced(string expression)
    {
        try
        {
            // Stack is used to track opening brackets
            Stack<char> stack = new Stack<char>();

            // Dictionary to map closing brackets to their matching opening brackets
            Dictionary<char, char> matchingBrackets = new Dictionary<char, char>
            {
                { ')', '(' },
                { '}', '{' },
                { ']', '[' }
            };

            // Loop through each character in the input string
            foreach (char ch in expression)
            {
                // If the character is an opening bracket, push it onto the stack
                if (ch == '(' || ch == '{' || ch == '[')
                {
                    stack.Push(ch);
                }
                // If the character is a closing bracket
                else if (ch == ')' || ch == '}' || ch == ']')
                {
                    // If the stack is empty, there's no matching opening bracket
                    if (stack.Count == 0)
                        return false;

                    // Pop the top of the stack and check if it matches the current closing bracket
                    char top = stack.Pop();

                    // If it doesn't match, the expression is not balanced
                    if (top != matchingBrackets[ch])
                        return false;
                }
                // Ignore other characters (optional enhancement)
            }

            // If stack is empty, all opening brackets were matched correctly
            return stack.Count == 0;
        }
        catch (Exception ex)
        {
            // If any unexpected error happens, log it and return false
            Console.WriteLine($"Error in IsBalanced: {ex.Message}");
            return false;
        }
    }
}
